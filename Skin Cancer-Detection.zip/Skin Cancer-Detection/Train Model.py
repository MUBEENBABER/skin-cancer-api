import os
import shutil
from sklearn.model_selection import train_test_split

# ✅ Create binary label: melanoma vs non_melanoma
metadata['binary_label'] = metadata['dx'].apply(lambda x: 'melanoma' if x == 'mel' else 'non_melanoma')

# ✅ Split dataset
train_df, val_df = train_test_split(
    metadata,
    test_size=0.2,
    stratify=metadata['binary_label'],
    random_state=42
)

# ✅ Create directory structure
base_dir = "binary_skin_data"
for split in ['train', 'val']:
    for label in ['melanoma', 'non_melanoma']:
        os.makedirs(os.path.join(base_dir, split, label), exist_ok=True)

# ✅ Copy images into correct folders
def copy_images(df, split):
    for _, row in df.iterrows():
        label = 'melanoma' if row['dx'] == 'mel' else 'non_melanoma'
        filename = row['image_id'] + ".jpg"
        src1 = os.path.join("skin_cancer_dataset/HAM10000_images_part_1", filename)
        src2 = os.path.join("skin_cancer_dataset/HAM10000_images_part_2", filename)
        src = src1 if os.path.exists(src1) else src2
        dst = os.path.join(base_dir, split, label, filename)
        if os.path.exists(src):
            shutil.copyfile(src, dst)

copy_images(train_df, 'train')
copy_images(val_df, 'val')








import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# ✅ Image settings
IMG_SIZE = (150, 150)
BATCH_SIZE = 32

# ✅ Data generators with fixed class order
train_datagen = ImageDataGenerator(rescale=1./255, horizontal_flip=True, zoom_range=0.2)
val_datagen = ImageDataGenerator(rescale=1./255)

train_data = train_datagen.flow_from_directory(
    'binary_skin_data/train',
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='binary',
    classes=['non_melanoma', 'melanoma']
)

val_data = val_datagen.flow_from_directory(
    'binary_skin_data/val',
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='binary',
    classes=['non_melanoma', 'melanoma']
)

# ✅ CNN Model
model = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32, (3,3), activation='relu', input_shape=(150,150,3)),
    tf.keras.layers.MaxPooling2D(2,2),
    tf.keras.layers.Conv2D(64, (3,3), activation='relu'),
    tf.keras.layers.MaxPooling2D(2,2),
    tf.keras.layers.Conv2D(128, (3,3), activation='relu'),
    tf.keras.layers.MaxPooling2D(2,2),
    tf.keras.layers.GlobalAveragePooling2D(),
    tf.keras.layers.Dense(128, activation='relu'),
    tf.keras.layers.Dense(1, activation='sigmoid')  # Binary classification
])

# ✅ Compile & Train
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
history = model.fit(train_data, epochs=10, validation_data=val_data)

# ✅ Save model
model.save("melanoma_binary_classifier.h5")
