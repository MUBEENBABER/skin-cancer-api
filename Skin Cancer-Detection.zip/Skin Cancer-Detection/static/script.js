const authButtons = document.getElementById('authButtons');
const uploadSection = document.getElementById('uploadSection');
const modal = document.getElementById('modalContainer');
const submitLogin = document.getElementById('submitLogin');
const usernameInput = document.getElementById('usernameInput');
const passwordInput = document.getElementById('passwordInput');
const loginBtn = document.getElementById('loginBtn');
const modalTitle = document.getElementById('modalTitle');

const uploadBtn = document.getElementById("uploadBtn");
const fileInput = document.getElementById("fileInput");
const uploadMessage = document.getElementById("uploadMessage");

let isLoginMode = true;

function updateAuthUI() {
  const user = JSON.parse(localStorage.getItem('currentUser'));
  if (user) {
    authButtons.innerHTML = `
      <span class="text-sm">Hi, ${user.username}</span>
      <button id="logoutBtn" class="bg-red-600 px-3 py-1 rounded-full hover:bg-red-700">Logout</button>
    `;
    document.getElementById('logoutBtn').addEventListener('click', () => {
      localStorage.removeItem('currentUser');
      location.reload();
    });
    uploadSection.classList.remove('hidden');
  }
}

loginBtn.addEventListener('click', () => {
  isLoginMode = true;
  modalTitle.textContent = "Login";
  modal.classList.remove('hidden');
});

submitLogin.addEventListener('click', () => {
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  if (!username || !password) {
    alert('Please fill in both fields.');
    return;
  }

  let users = JSON.parse(localStorage.getItem('users')) || {};

  if (isLoginMode) {
    if (users[username] && users[username] === password) {
      localStorage.setItem('currentUser', JSON.stringify({ username }));
      modal.classList.add('hidden');
      updateAuthUI();
    } else {
      alert('Invalid credentials!');
    }
  } else {
    if (users[username]) {
      alert('User already exists!');
    } else {
      users[username] = password;
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('currentUser', JSON.stringify({ username }));
      modal.classList.add('hidden');
      updateAuthUI();
    }
  }
});

// Upload Button Handler
uploadBtn.addEventListener("click", () => {
  if (!fileInput.files.length) {
    alert("Please select a file first.");
    return;
  }
  uploadMessage.classList.remove("hidden");
  uploadMessage.textContent = "✅ File uploaded successfully!";
});

function showSignup() {
  isLoginMode = false;
  modalTitle.textContent = "Sign Up";
  modal.classList.remove('hidden');
}

function forgotPassword() {
  alert("Feature coming soon!");
}

window.addEventListener('click', (e) => {
  if (e.target === modal) modal.classList.add('hidden');
});

updateAuthUI();
