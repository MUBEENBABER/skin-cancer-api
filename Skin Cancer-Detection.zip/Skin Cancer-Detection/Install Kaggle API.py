# ✅ Install Kaggle API
#!pip install -q kaggle

# ✅ Upload kaggle.json
from google.colab import files
files.upload()  # Select kaggle.json from your machine

# ✅ Set up Kaggle API credentials
!mkdir -p ~/.kaggle
!cp kaggle.json ~/.kaggle/
!chmod 600 ~/.kaggle/kaggle.json

# ✅ Download and unzip HAM10000 dataset
!kaggle datasets download -d kmader/skin-cancer-mnist-ham10000
!unzip -q skin-cancer-mnist-ham10000.zip -d skin_cancer_dataset







import pandas as pd
import matplotlib.pyplot as plt

# ✅ Load metadata
metadata = pd.read_csv("skin_cancer_dataset/HAM10000_metadata.csv")
print(metadata.head())

# ✅ Plot label distribution
metadata['dx'].value_counts().plot(kind='bar', color='skyblue')
plt.title('Class Distribution')
plt.ylabel('Image Count')
plt.show()
